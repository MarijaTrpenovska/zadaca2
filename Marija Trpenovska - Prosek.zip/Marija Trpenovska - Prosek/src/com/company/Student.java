package com.company;

import java.util.Arrays;

public class Student extends Human {

    private Grade[] grades;

    public Grade[] getGrades() {
        return grades;
    }

    public void setGrades(Grade[] grades) {
        this.grades = grades;
    }

    public void setGrade(Grade grade) {

        int lenght = this.grades.length;
        Grade[] newGrades = new Grade[lenght + 1];

        for (int i=0; i < lenght; i++) {
            newGrades[i] = this.grades[i];
        }
        newGrades[lenght] = grade;
        this.grades = newGrades;
    }

    public double getAverageGrade() {

        double sum = 0;

        for (Grade grade : this.grades) {
            sum += grade.getGrade();
        }

        return sum / this.grades.length;
    }

    @Override
    public String toString() {
        return "Student{" +
                "grades=" + Arrays.toString(grades) +
                '}';
    }
}
