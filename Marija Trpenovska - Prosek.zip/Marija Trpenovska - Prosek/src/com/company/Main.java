package com.company;

public class Main {

    public static void main(String[] args) {

        Student student = new Student();
        Grade[] grades = new Grade[3];
        Grade grade5 = new Grade();
        grade5.setGrade(5);
        grade5.setExamDate("2342");
        grade5.setSubject("Math");
        Grade grade6 = new Grade();
        grade6.setGrade(6);
        grade6.setExamDate("2342");
        grade6.setSubject("Math");
        Grade grade7 = new Grade();
        grade7.setGrade(7);
        grade7.setExamDate("2342");
        grade7.setSubject("Math");
        grades[0] = grade5;
        grades[1] = grade6;
        grades[2] = grade7;
        student.setGrades(grades);

        Grade grade8 = new Grade();
        grade8.setGrade(8);
        grade8.setExamDate("2342");
        grade8.setSubject("Math");

        student.setGrade(grade8);

        System.out.println(student);
        System.out.println(student.getAverageGrade());

    }
}
